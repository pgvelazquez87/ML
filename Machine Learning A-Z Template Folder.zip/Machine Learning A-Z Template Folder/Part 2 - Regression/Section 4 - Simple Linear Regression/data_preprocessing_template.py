# Data Preprocessing Template

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os

os.chdir('/Users/pablo/Documents/ML/Machine Learning A-Z Template Folder/Part 2 - Regression/Section 4 - Simple Linear Regression')
# Importing the dataset
dataset = pd.read_csv('Salary_Data.csv')

# X is the matrix of features; Y is the matrix of dependent variable
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, 1].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.333, random_state = 0)

# Feature Scaling
"""from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)"""

# Fitting Simple Linear Regression in the Training Set
from sklearn.linear_model import LinearRegression

regressor = LinearRegression()
regressor.fit(X_train, y_train)


# Create the vector of Predicting Salaries based on our model
y_pred = regressor.predict(X_test)


# Visualizing the Training Set results
plt.scatter(x = X_train, y = y_train, color='red')
plt.plot(X_train, regressor.predict(X_train), color='blue')
plt.title('Salary vs. Expected Salaries (training set)')
plt.xlabel('Years of experience')
plt.ylabel('Salary')
plt.show()

# Visualizing the Test Set results
plt.scatter(X_test, y_test, color='red')
plt.plot(X_train, regressor.predict(X_train), color='blue')
plt.title('Salary vs. Expected Salaries (Test set)')
plt.xlabel('Years of experience')
plt.ylabel('Salary')
plt.show()