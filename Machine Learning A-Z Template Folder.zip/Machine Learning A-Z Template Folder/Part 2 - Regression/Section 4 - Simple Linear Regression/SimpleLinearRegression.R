## Simple Linear Regression

setwd('/Users/pablo/Documents/ML/Machine Learning A-Z Template Folder/Part 2 - Regression/Section 4 - Simple Linear Regression')

dataset <- read.csv('Salary_Data.csv')

# Split data
library(caTools)

set.seed(123)
#split_ratio determina el porcentaje de valores que serán para el training set (los FALSE van al test set)
split <- sample.split(dataset$Salary, SplitRatio = 2/3)

training_set <- subset(dataset, split==TRUE)
test_set <- subset(dataset, split==FALSE)


## Feature Scaling
#training_set[, 2:3] <- scale(training_set[, 2:3])
#test_set[, 2:3] <- scale(test_set[, 2:3])


# Fitting Simple Linear Regression to the Training Set
regressor <- lm(formula = Salary ~ YearsExperience, data = training_set)


# Predicting the Test set results
y_pred <- predict(regressor, newdata= test_set)


# Visualizing the results
library(ggplot2)

#Our model in our training set
ggplot() + 
  geom_point(aes(x=training_set$YearsExperience, y=training_set$Salary), 
             color='red') + 
  geom_line(aes(x=training_set$YearsExperience, 
              y = predict(regressor, newdata = training_set)), color='blue') + 
  ggtitle('Salary vs. Experience (training set)') +
  xlab('Years of experience') + ylab('Salary')

#our model in our test data
ggplot() + 
  geom_point(aes(x=test_set$YearsExperience, y=test_set$Salary), color='red') + 
  geom_line(aes(x=training_set$YearsExperience, 
                y = predict(regressor, newdata = training_set)), color='blue') + 
  ggtitle('Salary vs. Experience (test set)') +
  xlab('Years of experience') + ylab('Salary')

